<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Profile</title>
  <link rel="stylesheet" href="_dashboard.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
  <div class="container">
    <h2>Employee Profile</h2>

    <div class="profile-header">
      <img src="profile-pic-placeholder.jpg" alt="Profile Picture" class="profile-img">
      <h3 id="userName">John Doe</h3>
      <p id="userEmail">john@doe.com</p>
      <p id="userDOB">DOB - 1 Jan 1990</p>
      <button id="editProfileBtn" class="btn">Edit Profile</button>
    </div>

    <div class="profile-details">
      <div class="details-section">
        <h4>Qualifications</h4>
        <ul id="qualificationsList">
          <!-- Qualifications will be loaded here -->
        </ul>
        <button id="addQualification" class="btn">Add Qualification</button>
      </div>

      <div class="details-section">
        <h4>Experiences</h4>
        <ul id="experiencesList">
          <!-- Experiences will be loaded here -->
        </ul>
        <button id="addExperience" class="btn">Add Experience</button>
      </div>

      <div class="details-section">
        <h4>Current Address</h4>
        <p id="currentAddress">Ghaffar Market, Block 23, New Delhi, Delhi</p>
      </div>

      <div class="details-section">
        <h4>Permanent Address</h4>
        <p id="permanentAddress">Vittal Mallya Rd, Bengaluru, Karnataka</p>
      </div>
    </div>
  </div>

  <!-- Modal for editing profile -->
  <div id="editProfileModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <h3>Edit Profile</h3>
      <form id="editProfileForm">
        <input type="text" id="editName" placeholder="Full Name">
        <input type="email" id="editEmail" placeholder="Email">
        <input type="date" id="editDOB" placeholder="Date of Birth">
        <textarea id="editAddress" placeholder="Address"></textarea>
        <button type="submit" class="btn">Save Changes</button>
      </form>
    </div>
  </div>

  <script src="dashboard.js"></script>
</body>
</html>


<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Profile</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <div class="profile-container">
    <h1>Employee Profile</h1>

    Profile Section
    <div class="profile-header">
      <div class="profile-picture">
        <img src="https://via.placeholder.com/100" alt="Profile Picture">
        <i class="fas fa-pen edit-icon"></i>
      </div>
      <h2>John Doe</h2>
      <p>john@doe.com</p>
      <p>DOB - 1 Jan 1990</p>
    </div>

    Qualifications and Experiences Section
    <div class="profile-details">
      <div class="qualifications">
        <h3>Qualifications</h3>
        <ul>
          <li>B.Tech (Computer Science)</li>
          <li>
            Intermediate
            <i class="fas fa-pen edit-icon"></i>
          </li>
          <li>High School</li>
        </ul>
        <a href="#">Add Qualification</a>
      </div>

      <div class="experiences">
        <h3>Experiences</h3>
        <div class="experience-input">
          <input type="text" placeholder="Fresh">
          <i class="fas fa-save"></i>
        </div>
        <a href="#">Add Experience</a>
      </div>
    </div>

    Address Section
    <div class="profile-address">
      <div class="current-address">
        <h3>Current Address</h3>
        <p>Ghaffar Market, Block 23,</p>
        <p>Beadonpura, Karol Bagh,</p>
        <p>New Delhi</p>
        <p>Delhi</p>
      </div>

      <div class="permanent-address">
        <h3>Permanent Address</h3>
        <p>Vittal Mallya Rd, KG Halli,</p>
        <p>D' Souza Layout, Ashok Nagar</p>
        <p>Bengaluru</p>
        <p>Karnataka</p>
      </div>
    </div>
  </div>
</body>
</html> -->
