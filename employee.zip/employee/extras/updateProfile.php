<?php
require_once 'Database.php'; // Include the database connection class
session_start();

if (!isset($_SESSION['user_id'])) {
  die("Not logged in");
}

$userId = $_SESSION['user_id'];
$name = $_POST['name'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$address = $_POST['address'];

$db = new Database();

$sql = "UPDATE users SET name = :name, email = :email, dob = :dob, current_address = :address WHERE user_id = :user_id";
$stmt = $db->getConnection()->prepare($sql);
$result = $stmt->execute([
  'name' => $name,
  'email' => $email,
  'dob' => $dob,
  'address' => $address,
  'user_id' => $userId,
]);

if ($result) {
  echo "Profile updated successfully!";
} else {
  echo "Error updating profile.";
}
?>
