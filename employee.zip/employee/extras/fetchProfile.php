<?php
require_once 'Database.php'; // Include the database connection class
session_start();

if (!isset($_SESSION['user_id'])) {
  die("Not logged in");
}

$userId = $_SESSION['user_id'];
$db = new Database();

$sql = "SELECT * FROM users WHERE user_id = :user_id";
$stmt = $db->getConnection()->prepare($sql);
$stmt->execute(['user_id' => $userId]);
$user = $stmt->fetch();

$response = [
  'name' => $user['name'],
  'email' => $user['email'],
  'dob' => $user['dob'],
  'current_address' => $user['current_address'],
  'permanent_address' => $user['permanent_address'],
  'qualifications' => explode(',', $user['qualifications']),
  'experiences' => explode(',', $user['experiences']),
];

echo json_encode($response);
?>
