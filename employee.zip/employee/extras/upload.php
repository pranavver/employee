<?php
if (isset($_POST['submit'])) {
    // Check if the file was uploaded properly
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        print_r($_FILES['file']);
        echo "<br>";
        // Get file details
        $file = $_FILES['file'];
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];
        $fileType = $file['type'];

        // Print file details for debugging
        echo "File Name: $fileName<br>";
        echo "Temporary Location: $fileTmpName<br>";
        echo "File Size: $fileSize bytes<br>";
        echo "File Type: $fileType<br>";
    } else {
        echo "File upload error or no file uploaded.";
    }
}
