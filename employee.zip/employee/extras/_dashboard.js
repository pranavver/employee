$(document).ready(function () {
    // Fetch profile data on page load
    fetchProfileData();
  
    // Fetch Profile Data function
    function fetchProfileData() {
      $.ajax({
        url: 'fetchProfile.php',
        method: 'GET',
        dataType: 'json',
        success: function (response) {
          // Populate profile data
          $('#userName').text(response.name);
          $('#userEmail').text(response.email);
          $('#userDOB').text("DOB - " + response.dob);
          $('#currentAddress').text(response.current_address);
          $('#permanentAddress').text(response.permanent_address);
  
          // Populate qualifications
          var qualifications = response.qualifications;
          var qualificationList = $('#qualificationsList');
          qualificationList.empty();
          qualifications.forEach(function (qual) {
            qualificationList.append('<li>' + qual + '</li>');
          });
  
          // Populate experiences
          var experiences = response.experiences;
          var experienceList = $('#experiencesList');
          experienceList.empty();
          experiences.forEach(function (exp) {
            experienceList.append('<li>' + exp + '</li>');
          });
        }
      });
    }
  
    // Edit Profile modal
    $('#editProfileBtn').click(function () {
      $('#editProfileModal').fadeIn();
    });
  
    $('.close').click(function () {
      $('#editProfileModal').fadeOut();
    });
  
    // Submit edited profile data
    $('#editProfileForm').submit(function (e) {
      e.preventDefault();
      var updatedData = {
        name: $('#editName').val(),
        email: $('#editEmail').val(),
        dob: $('#editDOB').val(),
        address: $('#editAddress').val(),
      };
  
      $.ajax({
        url: 'updateProfile.php',
        method: 'POST',
        data: updatedData,
        success: function (response) {
          alert(response);
          fetchProfileData(); // Refresh the profile data
          $('#editProfileModal').fadeOut(); // Close the modal
        }
      });
    });
  });
  