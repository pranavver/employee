<?php
use Exception;

class Database {
    private $host = 'localhost';
    private $username = 'root';
    private $password = '';
    private $dbName = 'employee';
    private $conn;

    public function __construct() {
        $this->getConnection();
    }

    public function getConnection() {
        try {
            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->dbName);
        } catch (mysqli_sql_exception $e) {
            throw new Exception('Error in connection: ' . $e->getMessage());
        }
        return $this->conn;
    }

    public function closeConnection() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    public function query($sql) {
        try {
            $result = $this->conn->query($sql);
            if (!$result) {
                throw new Exception('Query failed: ' . $this->conn->error);
            }
            return $result;
        } catch (Exception $e) {
            throw new Exception('Error executing query: ' . $e->getMessage());
        }
    }

    function logIn($table, $username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $this->sql = "select * from " . $table . " where username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['username'];
            $dbpassword = $row['password'];
            if ($dbusername == $username && password_verify($password, $dbpassword)) {
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    function signUp($table, $fullname, $email, $username, $password)
    {
        $fullname = $this->prepareData($fullname);
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $email = $this->prepareData($email);
        $password = password_hash($password, PASSWORD_DEFAULT);
        $this->sql =
            "INSERT INTO " . $table . " (fullname, username, password, email) VALUES ('" . $fullname . "','" . $username . "','" . $password . "','" . $email . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
}





// use PDO;
// use Exception;
// class Database {
//     private $host = 'localhost';
//     private $dbName = 'your_database';
//     private $username = 'root';
//     private $password = '';
//     private $connection;

//     public function __construct() {
//         try {
//             $this->connection = new PDO("mysql:host={$this->host};dbname={$this->dbName}", $this->username, $this->password);
//             $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//         } catch (PDOException $e) {
//             throw new Exception("Database connection failed: " . $e->getMessage());
//         }
//     }

//     public function getConnection() {
//         return $this->connection;
//     }
// }


