<?php
require_once 'Database.php';

$response = ['success' => false, 'message' => ''];

// if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'register') {
//     try {
//         $db = new Database();
//         $conn = $db->getConnection();

//         // Gather form data
//         $fullName = $_POST['fullName'];
//         $dob = $_POST['dob'];
//         $email = $_POST['email'];
//         $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

//         // Handle profile picture
//         $profilePic = null;
//         if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] === UPLOAD_ERR_OK) {
//             $profilePic = 'uploads/' . uniqid() . '-' . $_FILES['profilePic']['name'];
//             move_uploaded_file($_FILES['profilePic']['tmp_name'], $profilePic);
//         }

//         // Insert into database
//         $query = "INSERT INTO users (full_name, dob, email, password, profile_pic) VALUES (:full_name, :dob, :email, :password, :profile_pic)";
//         $stmt = $conn->prepare($query);
//         $stmt->execute([
//             ':full_name' => $fullName,
//             ':dob' => $dob,
//             ':email' => $email,
//             ':password' => $password,
//             ':profile_pic' => $profilePic,
//         ]);

//         $response['success'] = true;
//         $response['message'] = 'Registration successful!';

//     } catch (Exception $e) {
//         $response['message'] = 'Error: ' . $e->getMessage();
//     }
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'register') {
    try {
        $db = new Database();
        $conn = $db->getConnection();

        // Gather form data
        $fullName = $_POST['fullName'];
        $dob = $_POST['dob'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Hash the password using bcrypt
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Handle profile picture (if uploaded)
        $profilePic = null;
        if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] === UPLOAD_ERR_OK) {
            $profilePic = 'uploads/' . uniqid() . '-' . $_FILES['profilePic']['name'];
            move_uploaded_file($_FILES['profilePic']['tmp_name'], $profilePic);
        }

        // Insert user data into the database
        $query = "INSERT INTO users (full_name, dob, email, password, profile_pic) VALUES (:full_name, :dob, :email, :password, :profile_pic)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':full_name' => $fullName,
            ':dob' => $dob,
            ':email' => $email,
            ':password' => $hashedPassword,
            ':profile_pic' => $profilePic,
        ]);

        $response['success'] = true;
        $response['message'] = 'Registration successful!';
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    }
}



echo json_encode($response);
?>
