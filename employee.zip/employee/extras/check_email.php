<?php
require_once '../database/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $query = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $response['success'] = true;
        $response['message'] = 'Registration successful!';
        echo json_encode(['exists' => true, 'message' => 'Email already exists.']);
    } else {
        $response['success'] = false;
        $response['message'] = 'Error: hai registration failed!';
        echo json_encode(['exists' => false, 'message' => 'Email is available.']);
    }

    $stmt->close();
    $conn->close();
}
?>


<?php
// header('Content-Type: application/json');

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     $email = $_POST['email'] ?? '';

//     // Simulate a database check
//     $existingEmails = ['test@example.com', 'user@example.com'];

//     if (in_array($email, $existingEmails)) {
//         echo json_encode(['exists' => true, 'message' => 'Email already exists.']);
//     } else {
//         echo json_encode(['exists' => false, 'message' => 'Email is available.']);
//     }
// } else {
//     echo json_encode(['exists' => false, 'message' => 'Invalid request.']);
// }
?>